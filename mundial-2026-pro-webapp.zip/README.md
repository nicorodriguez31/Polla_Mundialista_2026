# Mundial 2026 Pro

Versión más completa de la app web creada desde tu Excel.

## Qué hace
- Cargar resultados oficiales de partidos
- Ver tabla automática por grupo
- Crear participantes
- Registrar pronósticos por participante
- Calcular ranking automáticamente
- Cambiar sistema de puntos
- Exportar / importar respaldo en JSON
- Usar modo demo para probar rápido

## Cómo abrir
Solo abre `index.html` en tu navegador.

## Cómo subirla gratis
Puedes subir esta carpeta o el ZIP a:
- Netlify
- Vercel
- GitHub Pages

## Recomendación
Si luego quieres una versión todavía más fuerte, el siguiente paso sería:
- login real por usuario
- base de datos online
- compartir link para que 70 personas entren al tiempo
- cierre automático de pronósticos antes de cada partido
- fases finales y campeón
